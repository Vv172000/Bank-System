package com.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.bank.entity.UserPojo;
import com.bank.respo.BankRespo;
import com.bank.service.BankService;

@Service
public class BankService {
	
	@Autowired
	public BankRespo bankrespo;

	
//	public UserPojo saveUser(UserPojo userpojo) {
//		
//		return bankrespo.save(userpojo);
//	}


	public UserPojo saveUser(String name, String phno, String email,double balance) {
		UserPojo pojo=new UserPojo();
		pojo.setName(name);
		pojo.setPhno(phno);
		pojo.setPhno(phno);
		pojo.setEmail(email);
		pojo.setBalance(balance);
		return bankrespo.save(pojo);
	}



	public List<UserPojo> readData() {
		
		
		return bankrespo.findAll();
	}

//
//	@Override
//	public UserPojo updateData(UserPojo userpojo, Long useriLong) {
//		
//		return null;
//	}
//
//	@Override
	public void deleteData(Long userId) {
		
		bankrespo.deleteById(userId);
		
		
	}
}
//}
